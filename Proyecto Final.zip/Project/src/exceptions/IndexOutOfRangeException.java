package exceptions;

public class IndexOutOfRangeException extends Exception {

	public IndexOutOfRangeException(String message) {
		super(message);
	}
	
	
}
