package exceptions;

public class ElementOutOfTreeException extends Exception {

	public ElementOutOfTreeException(String message) {
		super(message);
	}
	
}
