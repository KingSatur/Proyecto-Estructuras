package model;

import graph.Directed.AdjacencyMatrix;
import graph.Directed.Node;
import graph.Undirected.AdjacencyListUndirected;
import graph.Undirected.AdjacencyMatrixUndirected;

public class Graphs {
	
	private AdjacencyMatrix<Point, Integer> simpleDirectedGraph;
	private AdjacencyMatrixUndirected<Point, Integer> simpleUndirectedGraph;
	private AdjacencyListUndirected<Point, Integer> undirectedMultigraph;
	private AdjacencyListUndirected<Point, Integer> undirectedPseudoGraph;
	
	
	
	public Graphs() {
		
		
	}
	
	
	
	public void createSimpleUndirectedGraph() {
		
		simpleUndirectedGraph = new AdjacencyMatrixUndirected<Point, Integer>();
		
		Point p1 = new Point(160, 190, 15);
		Point p2 = new Point(460, 190, 15);
		Point p3 = new Point(310, 400, 15);
		
		simpleUndirectedGraph.addNode(new Node<Point, Integer>(p1, 1));
		simpleUndirectedGraph.addNode(new Node<Point, Integer>(p2, 2));
		simpleUndirectedGraph.addNode(new Node<Point, Integer>(p3, 3));
		
		simpleUndirectedGraph.addEdge(1, 2, 6, 1);
		simpleUndirectedGraph.addEdge(1, 3, 2, 2);
		simpleUndirectedGraph.addEdge(3, 2, 3, 3);
		
	}
	
	public void createSimpleGraph() {
		simpleDirectedGraph = new AdjacencyMatrix<Point, Integer>();
		
		Point p1 = new Point(160, 190, 15);
		Point p2 = new Point(460, 190, 15);
	
		
		simpleDirectedGraph.addNode(new Node<Point, Integer>(p1, 1));
		simpleDirectedGraph.addNode(new Node<Point, Integer>(p2, 2));
		
		simpleDirectedGraph.addEdge(1, 2, 7, 1);
		
	}
	
	public void createMultigraphUndirected() {
		undirectedMultigraph = new AdjacencyListUndirected<Point, Integer>();
	}
	
	public void createPseudoGraph() {
		undirectedPseudoGraph = new AdjacencyListUndirected<Point, Integer>();		
	}
	

	public AdjacencyMatrix<Point, Integer> getSimpleDirectedGraph() {
		return simpleDirectedGraph;
	}


	public void setSimpleDirectedGraph(AdjacencyMatrix<Point, Integer> simpleDirectedGraph) {
		this.simpleDirectedGraph = simpleDirectedGraph;
	}


	public AdjacencyMatrixUndirected<Point, Integer> getSimpleUndirectedGraph() {
		return simpleUndirectedGraph;
	}


	public void setSimpleUndirectedGraph(AdjacencyMatrixUndirected<Point, Integer> simpleUndirectedGraph) {
		this.simpleUndirectedGraph = simpleUndirectedGraph;
	}


	public AdjacencyListUndirected<Point, Integer> getUndirectedMultigraph() {
		return undirectedMultigraph;
	}


	public void setUndirectedMultigraph(AdjacencyListUndirected<Point, Integer> undirectedMultigraph) {
		this.undirectedMultigraph = undirectedMultigraph;
	}


	public AdjacencyListUndirected<Point, Integer> getUndirectedPseudoGraph() {
		return undirectedPseudoGraph;
	}


	public void setUndirectedPseudoGraph(AdjacencyListUndirected<Point, Integer> undirectedPseudoGraph) {
		this.undirectedPseudoGraph = undirectedPseudoGraph;
	}
	
	public static void main(String[] args) {
		
		Graphs g = new Graphs();
		
	
		
	}
	
}
