package dataStructures;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

import exceptions.IndexOutOfRangeException;
import exceptions.StackEmptyException;
import tda.InterfaceCampiList;
import tda.InterfaceCampiQueue;
import tda.InterfaceCampiStack;

public class Test {
	
	
//	public boolean isBalanced(String word) {
//		
//		InterfaceCampiStack<Character> campiStack = new Abstract<Character>();
//		char[] brackets = word.toCharArray();
//		boolean leave = false;
//		
//		for(int i = 0; i < brackets.length && !leave ; i ++) {
//			if(brackets[i] == '{' || brackets[i] == '['|| brackets[i] == '(') {
//				Node<Character> newNode = new Node<Character>(brackets[i]);
//				campiStack.push(newNode);
//			}
//			else { 
//				if(brackets[i] == '}' || brackets[i] == ']'|| brackets[i] == ')') {
//					if(!campiStack.isEmpty()) {
//						if(campiStack.isArmonic(campiStack.top().getData(), brackets[i])) {
//							try {
//								campiStack.pop();
//							}
//							catch(Exception e) {
//							
//							}
//						}
//						else {
//							leave = true;
//							return campiStack.isEmpty();
//						}
//					}
//					else {
//						leave = true;
//						return false;
//					}
//				}
//			}
//		}
//		
//		return campiStack.isEmpty();		
//	}
	
//	public void read() throws IOException {
//		FileReader file = new FileReader("FilesTest/testCases.txt");
//		File m = new File("FilesTest/resultados.txt");
//		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));
//		BufferedReader br = new BufferedReader(file);
//		String cadena = br.readLine();
//		long limit = Long.parseLong(cadena);
//		for(long i = 0; i < 1000; i ++) {
//			cadena = br.readLine();
//			System.out.println(isBalanced(cadena));
//		}
//				
//		
//	}

	
	public static void main(String[] args) {
		
//		CampiHash<CampiList<Player>> hash = new  CampiHash<CampiList<Player>>();
//		hash.getHash()[0] = new CampiList<Player>();

//		if(hash.getHash()[0] instanceof CampiList) {
//			 ((CampiList)hash.getHash()[0]).addElement(new Player("alberto", 1));   
		}
		
		
		
		

//		hash.get(0).addElement(new Player("Juan",90));
//		System.out.println(hash.get(0).getFirstNode().getData().getName());
//
	
	
}