package graphicInterface;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.util.HashMap;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import graph.Directed.EdgeSrcEnd;
import graph.Directed.Node;
import model.Point;

public class DialogMultiGraphUndirected extends JDialog {

	public final static int ANCHO = 1000;
	public final static int ALTO = 550;
	
	private PanelMultiUndirected panelMultiUndirected;
	private final JPanel contentPanel = new JPanel();
	private Main main;

	

	/**
	 * Create the dialog.
	 */
	public DialogMultiGraphUndirected(Main main, HashMap<Integer, Node<Point, Integer>> nodes, EdgeSrcEnd<Integer>[][] matrix) {
		this.main = main;
		panelMultiUndirected = new PanelMultiUndirected(main, nodes, matrix);
		
		setSize(ANCHO, ALTO);
		setLayout(new BorderLayout());
		JLabel lblNewLabel = new JLabel("Multigrafo No Dirigido");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		add(lblNewLabel, BorderLayout.NORTH);
		add(panelMultiUndirected, BorderLayout.CENTER);
		
		setResizable(false);
	}



	public PanelMultiUndirected getPanelMultiUndirected() {
		return panelMultiUndirected;
	}
	
	
	

}
