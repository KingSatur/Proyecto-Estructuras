package graphicInterface;

import java.awt.BorderLayout;
import java.util.HashMap;

import javax.swing.JPanel;

import graph.Directed.EdgeSrcEnd;
import graph.Directed.Node;
import model.Point;

public class PanelPseudo extends JPanel {

	private PanelCanvasList panelCanvas;
	private Main main;
	
	public PanelPseudo(Main main, HashMap<Integer, Node<Point, Integer>> nodes, EdgeSrcEnd<Integer>[][] matrix ) {
		
		this.main =  main;
		setLayout(new BorderLayout());
//		panelCanvas = new PanelCanvasList(main, nodes, /**tus adj*/);

		add(panelCanvas, BorderLayout.CENTER);

	}

	public PanelCanvasList getPanelCanvas() {
		return panelCanvas;
	}

	public void setPanelCanvas(PanelCanvasList panelCanvas) {
		this.panelCanvas = panelCanvas;
	}

}
