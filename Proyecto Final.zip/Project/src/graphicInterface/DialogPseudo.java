package graphicInterface;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.util.HashMap;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import graph.Directed.EdgeSrcEnd;
import graph.Directed.Node;
import model.Point;

public class DialogPseudo extends JDialog {

	public final static int ANCHO = 1000;
	public final static int ALTO = 550;
	
	private final JPanel contentPanel = new JPanel();
	private PanelPseudo panelPseudo;
	private Main main;
	
	public DialogPseudo(Main main, HashMap<Integer, Node<Point, Integer>> nodes, EdgeSrcEnd<Integer>[][] matrix) {
		this.main = main;
		panelPseudo = new PanelPseudo(main, nodes, matrix); 
		
		setSize(ANCHO, ALTO);
		setLayout(new BorderLayout());
		JLabel lblNewLabel = new JLabel("Pseudo Grafo");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		add(lblNewLabel, BorderLayout.NORTH);
		add(panelPseudo, BorderLayout.CENTER);
		
	}

	public PanelPseudo getPanelPseudo() {
		return panelPseudo;
	}
	
	

}
